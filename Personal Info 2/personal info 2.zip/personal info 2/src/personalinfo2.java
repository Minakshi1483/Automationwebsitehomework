public class personalinfo2 {

       public static void main(String[]args){

//print first name
              String firstname = "Dhivit";
              //print age
              int age = 30;
              //print mobile no
              int mobilenumber = 75689057;
              //print visa status
              String visastatus="true";
              //print city
              String city = "london";
              //print postcode
              String postcode = "ha4 3bl";
              //print address
              String address = "1 rosemary garden";}



}

